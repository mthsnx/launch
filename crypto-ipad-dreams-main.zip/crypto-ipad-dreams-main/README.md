# Crypto Ipad Dreams

make a website for a ipad store. payments in crypto only. make it fully encrypted and very secure. make it use nowpayments to recive payments trough crypto and make it look very clean. admin panel. overview of how much money recived etc.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://crypto-ipad-dreams.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/ff50151c-f612-4d6c-b951-1115ad70a63a).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
