create type public.app_role as enum ('admin','user');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "own roles readable" on public.user_roles for select to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role app_role)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = _user_id and role = _role) $$;

-- First account ever created becomes the store admin
create or replace function public.handle_new_user_role()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if not exists (select 1 from public.user_roles where role = 'admin') then
    insert into public.user_roles (user_id, role) values (new.id, 'admin');
  end if;
  insert into public.user_roles (user_id, role) values (new.id, 'user') on conflict do nothing;
  return new;
end; $$;
create trigger on_auth_user_created_role after insert on auth.users
for each row execute function public.handle_new_user_role();

create table public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  storage text not null,
  price_eur numeric(10,2) not null,
  sort int not null default 0,
  active boolean not null default true
);
grant select on public.products to anon, authenticated;
grant all on public.products to service_role;
alter table public.products enable row level security;
create policy "active products public" on public.products for select to anon, authenticated using (active);

insert into public.products (name, storage, price_eur, sort) values
('iPad Pro 12.9" (5th gen)', '128 GB', 899, 1),
('iPad Pro 12.9" (5th gen)', '256 GB', 999, 2),
('iPad Pro 12.9" (5th gen)', '512 GB', 1199, 3);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  email text,
  product_id uuid references public.products(id) not null,
  product_label text not null,
  amount_eur numeric(10,2) not null,
  shipping_name text not null,
  shipping_address text not null,
  status text not null default 'waiting',
  invoice_id text,
  pay_currency text,
  actually_paid numeric,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select on public.orders to authenticated;
grant all on public.orders to service_role;
alter table public.orders enable row level security;
create policy "own orders" on public.orders for select to authenticated using (auth.uid() = user_id);
create policy "admins see all orders" on public.orders for select to authenticated using (public.has_role(auth.uid(),'admin'));