import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

type CheckoutInput = { productId: string; shippingName: string; shippingAddress: string };

function validate(input: unknown): CheckoutInput {
  const i = input as Record<string, unknown>;
  const productId = String(i?.["productId"] ?? "");
  const shippingName = String(i?.["shippingName"] ?? "").trim();
  const shippingAddress = String(i?.["shippingAddress"] ?? "").trim();
  if (!/^[0-9a-f-]{36}$/i.test(productId)) throw new Error("Invalid product");
  if (shippingName.length < 2 || shippingName.length > 120) throw new Error("Enter your full name");
  if (shippingAddress.length < 8 || shippingAddress.length > 500) throw new Error("Enter a full shipping address");
  return { productId, shippingName, shippingAddress };
}

export const createCryptoCheckout = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(validate)
  .handler(async ({ data, context }) => {
    const apiKey = process.env["NOWPAYMENTS_API_KEY"];
    if (!apiKey) throw new Error("Payments are not configured yet");

    // Price always comes from the database, never from the browser
    const { data: product, error: pErr } = await context.supabase
      .from("products")
      .select("id, name, storage, price_eur")
      .eq("id", data.productId)
      .single();
    if (pErr || !product) throw new Error("Product not found");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const email = (context.claims as { email?: string })?.email ?? null;
    const label = `${product.name} · ${product.storage}`;

    const { data: order, error: oErr } = await supabaseAdmin
      .from("orders")
      .insert({
        user_id: context.userId,
        email,
        product_id: product.id,
        product_label: label,
        amount_eur: product.price_eur,
        shipping_name: data.shippingName,
        shipping_address: data.shippingAddress,
      })
      .select("id")
      .single();
    if (oErr || !order) throw new Error("Could not create order");

    const origin = new URL(getRequest().url).origin;
    const res = await fetch("https://api.nowpayments.io/v1/invoice", {
      method: "POST",
      headers: { "x-api-key": apiKey, "Content-Type": "application/json" },
      body: JSON.stringify({
        price_amount: Number(product.price_eur),
        price_currency: "eur",
        order_id: order.id,
        order_description: label,
        ipn_callback_url: `${origin}/api/public/nowpayments-ipn`,
        success_url: `${origin}/orders?paid=1`,
        cancel_url: `${origin}/`,
      }),
    });
    if (!res.ok) {
      console.error("NOWPayments invoice failed", res.status, await res.text());
      await supabaseAdmin.from("orders").update({ status: "failed" }).eq("id", order.id);
      throw new Error("Payment provider unavailable, please try again");
    }
    const invoice = (await res.json()) as { id: string | number; invoice_url: string };
    await supabaseAdmin.from("orders").update({ invoice_id: String(invoice.id) }).eq("id", order.id);
    return { url: invoice.invoice_url };
  });
