export const eur = (n: number | string) =>
  new Intl.NumberFormat("en-IE", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(Number(n));

export const statusLabel: Record<string, string> = {
  waiting: "Awaiting payment",
  confirming: "Confirming",
  confirmed: "Paid",
  sending: "Paid",
  finished: "Paid",
  partially_paid: "Partially paid",
  failed: "Failed",
  refunded: "Refunded",
  expired: "Expired",
};
