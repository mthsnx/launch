import { PAID_STATUSES } from "@/lib/ipn";

export function StatusBadge({ status, label }: { status: string; label: string }) {
  const tone = PAID_STATUSES.includes(status)
    ? "bg-success/15 text-success"
    : ["failed", "expired", "refunded"].includes(status)
      ? "bg-destructive/10 text-destructive"
      : "bg-warning/20 text-foreground";
  return <span className={`mt-1 inline-block rounded-full px-2 py-0.5 text-xs font-medium ${tone}`}>{label}</span>;
}
