import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Bitcoin, Lock, Truck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { createCryptoCheckout } from "@/lib/store.functions";
import { useSession } from "@/hooks/use-session";
import { eur } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import hero from "@/assets/hero-ipad.jpg";

const productsQuery = queryOptions({
  queryKey: ["products"],
  queryFn: async () => {
    const { data, error } = await supabase.from("products").select("*").order("sort");
    if (error) throw error;
    return data;
  },
});

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Slate — iPad Pro 12.9\" paid in crypto" },
      { name: "description", content: "Buy the iPad Pro 12.9-inch (5th gen) with Bitcoin, Ethereum, USDT and 300+ cryptocurrencies." },
      { property: "og:title", content: "Slate — iPad Pro paid in crypto" },
      { property: "og:description", content: "Buy the iPad Pro 12.9-inch with Bitcoin, Ethereum, USDT and more." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(productsQuery),
  component: Index,
});

function Index() {
  const { data: products } = useSuspenseQuery(productsQuery);
  const { user } = useSession();
  const [selected, setSelected] = useState(products[0]?.id);
  const [name, setName] = useState("");
  const [address, setAddress] = useState("");
  const [busy, setBusy] = useState(false);
  const checkout = useServerFn(createCryptoCheckout);
  const product = products.find((p) => p.id === selected);

  const pay = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selected) return;
    setBusy(true);
    try {
      const { url } = await checkout({ data: { productId: selected, shippingName: name, shippingAddress: address } });
      window.location.href = url;
    } catch (err) {
      toast.error((err as Error).message);
      setBusy(false);
    }
  };

  return (
    <main>
      <section className="relative overflow-hidden">
        <img src={hero} alt="iPad Pro 12.9-inch in silver" width={1600} height={1008} className="absolute inset-0 h-full w-full object-cover object-right" />
        <div className="relative mx-auto max-w-6xl px-6 py-28 md:py-40">
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-muted-foreground">iPad Pro 12.9" · 5th generation</p>
          <h1 className="mt-4 max-w-md text-5xl font-semibold leading-[1.05] tracking-tight md:text-6xl">
            Pro power.<br />Paid in crypto.
          </h1>
          <p className="mt-5 max-w-sm text-muted-foreground">M1 chip, Liquid Retina XDR display. Checkout with BTC, ETH, USDT and 300+ coins.</p>
          <Button asChild size="lg" className="mt-8">
            <a href="#buy">Buy from {eur(products[0]?.price_eur ?? 0)}</a>
          </Button>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-4 px-6 py-14 sm:grid-cols-3">
        {[
          { icon: Bitcoin, t: "Crypto only", d: "300+ coins via NOWPayments" },
          { icon: Lock, t: "Encrypted end to end", d: "TLS everywhere, signed payment callbacks" },
          { icon: Truck, t: "Insured shipping", d: "Ships once your payment confirms" },
        ].map(({ icon: I, t, d }) => (
          <div key={t} className="rounded-2xl border bg-card p-6">
            <I className="h-5 w-5 text-accent" />
            <p className="mt-4 font-medium">{t}</p>
            <p className="mt-1 text-sm text-muted-foreground">{d}</p>
          </div>
        ))}
      </section>

      <section id="buy" className="mx-auto max-w-6xl scroll-mt-20 px-6 pb-24">
        <div className="grid gap-10 rounded-3xl border bg-card p-8 shadow-soft md:grid-cols-2 md:p-12">
          <div>
            <h2 className="text-3xl font-semibold tracking-tight">Choose storage</h2>
            <div className="mt-6 space-y-3">
              {products.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setSelected(p.id)}
                  className={`flex w-full items-center justify-between rounded-xl border p-4 text-left transition ${selected === p.id ? "border-foreground ring-1 ring-foreground" : "hover:border-muted-foreground"}`}
                >
                  <span>
                    <span className="block font-medium">{p.storage}</span>
                    <span className="text-sm text-muted-foreground">{p.name}</span>
                  </span>
                  <span className="font-medium">{eur(p.price_eur)}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            {user ? (
              <form onSubmit={pay} className="space-y-4">
                <h2 className="text-3xl font-semibold tracking-tight">Shipping</h2>
                <div className="space-y-1.5">
                  <Label htmlFor="name">Full name</Label>
                  <Input id="name" required value={name} onChange={(e) => setName(e.target.value)} maxLength={120} />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="addr">Address</Label>
                  <Textarea id="addr" required rows={4} value={address} onChange={(e) => setAddress(e.target.value)} maxLength={500} />
                </div>
                <div className="flex items-center justify-between border-t pt-4">
                  <span className="text-muted-foreground">Total</span>
                  <span className="text-xl font-semibold">{product ? eur(product.price_eur) : "—"}</span>
                </div>
                <Button size="lg" className="w-full" disabled={busy}>
                  {busy ? "Opening secure checkout…" : "Pay with crypto"}
                </Button>
              </form>
            ) : (
              <div className="flex h-full flex-col justify-center">
                <h2 className="text-3xl font-semibold tracking-tight">Sign in to buy</h2>
                <p className="mt-2 text-muted-foreground">An account lets you track your order and payment.</p>
                <Button asChild size="lg" className="mt-6 self-start">
                  <Link to="/auth">Sign in or create account</Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      </section>
    </main>
  );
}
