import { createFileRoute } from "@tanstack/react-router";
import { verifyIpn } from "@/lib/ipn";

const ALLOWED = new Set(["waiting", "confirming", "confirmed", "sending", "partially_paid", "finished", "failed", "refunded", "expired"]);

export const Route = createFileRoute("/api/public/nowpayments-ipn")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const secret = process.env["NOWPAYMENTS_IPN_SECRET"];
        const sig = request.headers.get("x-nowpayments-sig");
        if (!secret || !sig) return new Response("Unauthorized", { status: 401 });

        let body: Record<string, unknown>;
        try {
          body = JSON.parse(await request.text());
        } catch {
          return new Response("Bad request", { status: 400 });
        }
        if (!(await verifyIpn(secret, body, sig))) return new Response("Invalid signature", { status: 401 });

        const orderId = String(body["order_id"] ?? "");
        const status = String(body["payment_status"] ?? "");
        if (!/^[0-9a-f-]{36}$/i.test(orderId) || !ALLOWED.has(status)) return new Response("Ignored", { status: 200 });

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        await supabaseAdmin
          .from("orders")
          .update({
            status,
            pay_currency: body["pay_currency"] ? String(body["pay_currency"]) : null,
            actually_paid: body["actually_paid"] != null ? Number(body["actually_paid"]) : null,
            updated_at: new Date().toISOString(),
          })
          .eq("id", orderId);
        return new Response("OK", { status: 200 });
      },
    },
  },
});
