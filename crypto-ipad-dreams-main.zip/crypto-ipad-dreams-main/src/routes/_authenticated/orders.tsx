import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { eur, statusLabel } from "@/lib/format";
import { StatusBadge } from "@/components/StatusBadge";

export const Route = createFileRoute("/_authenticated/orders")({
  head: () => ({
    meta: [
      { title: "My orders — Slate" },
      { name: "description", content: "Track your iPad orders and crypto payments." },
      { property: "og:title", content: "My orders — Slate" },
      { property: "og:description", content: "Track your iPad orders and crypto payments." },
    ],
  }),
  component: Orders,
});

function Orders() {
  const { data: orders = [], isLoading } = useQuery({
    queryKey: ["my-orders"],
    queryFn: async () => {
      const { data: u } = await supabase.auth.getUser();
      const { data, error } = await supabase.from("orders").select("*").eq("user_id", u.user!.id).order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    refetchInterval: 15000,
  });

  return (
    <main className="mx-auto max-w-3xl px-6 py-16">
      <h1 className="text-3xl font-semibold tracking-tight">Your orders</h1>
      <p className="mt-1 text-sm text-muted-foreground">Payment status updates automatically once the blockchain confirms.</p>
      <div className="mt-8 space-y-3">
        {isLoading && <p className="text-sm text-muted-foreground">Loading…</p>}
        {!isLoading && orders.length === 0 && <p className="text-sm text-muted-foreground">No orders yet.</p>}
        {orders.map((o) => (
          <div key={o.id} className="flex items-center justify-between rounded-xl border bg-card p-5">
            <div>
              <p className="font-medium">{o.product_label}</p>
              <p className="text-xs text-muted-foreground">
                {new Date(o.created_at).toLocaleString()} · #{o.id.slice(0, 8)}
              </p>
            </div>
            <div className="text-right">
              <p className="font-medium">{eur(o.amount_eur)}</p>
              <StatusBadge status={o.status} label={statusLabel[o.status] ?? o.status} />
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
