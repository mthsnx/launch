import { createFileRoute, redirect } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { eur, statusLabel } from "@/lib/format";
import { PAID_STATUSES } from "@/lib/ipn";
import { StatusBadge } from "@/components/StatusBadge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Admin overview — Slate" },
      { name: "description", content: "Revenue and orders overview." },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "Admin overview — Slate" },
      { property: "og:description", content: "Revenue and orders overview." },
    ],
  }),
  beforeLoad: async () => {
    const { data: u } = await supabase.auth.getUser();
    const { data } = await supabase.rpc("has_role", { _user_id: u.user!.id, _role: "admin" });
    if (!data) throw redirect({ to: "/" });
  },
  component: Admin,
});

function Admin() {
  const { data: orders = [] } = useQuery({
    queryKey: ["admin-orders"],
    queryFn: async () => {
      const { data, error } = await supabase.from("orders").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    refetchInterval: 20000,
  });

  const paid = orders.filter((o) => PAID_STATUSES.includes(o.status));
  const revenue = paid.reduce((s, o) => s + Number(o.amount_eur), 0);
  const pending = orders.filter((o) => ["waiting", "confirming", "partially_paid"].includes(o.status));
  const monthStart = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  const monthRevenue = paid.filter((o) => new Date(o.created_at) >= monthStart).reduce((s, o) => s + Number(o.amount_eur), 0);
  const byCoin = paid.reduce<Record<string, number>>((acc, o) => {
    const k = (o.pay_currency ?? "unknown").toUpperCase();
    acc[k] = (acc[k] ?? 0) + Number(o.amount_eur);
    return acc;
  }, {});

  const stats = [
    { l: "Total received", v: eur(revenue) },
    { l: "This month", v: eur(monthRevenue) },
    { l: "Paid orders", v: paid.length },
    { l: "Awaiting payment", v: pending.length },
  ];

  return (
    <main className="mx-auto max-w-6xl px-6 py-14">
      <h1 className="text-3xl font-semibold tracking-tight">Overview</h1>
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.l} className="rounded-2xl border bg-card p-6">
            <p className="text-sm text-muted-foreground">{s.l}</p>
            <p className="mt-2 text-3xl font-semibold tracking-tight">{s.v}</p>
          </div>
        ))}
      </div>

      {Object.keys(byCoin).length > 0 && (
        <div className="mt-6 rounded-2xl border bg-card p-6">
          <p className="text-sm text-muted-foreground">Received by coin (EUR value)</p>
          <div className="mt-3 flex flex-wrap gap-6">
            {Object.entries(byCoin).map(([c, v]) => (
              <div key={c}>
                <p className="font-mono text-xs text-muted-foreground">{c}</p>
                <p className="font-medium">{eur(v)}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="mt-6 rounded-2xl border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Product</TableHead>
              <TableHead>Ship to</TableHead>
              <TableHead>Coin</TableHead>
              <TableHead className="text-right">Amount</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {orders.length === 0 && (
              <TableRow>
                <TableCell colSpan={7} className="py-10 text-center text-muted-foreground">No orders yet.</TableCell>
              </TableRow>
            )}
            {orders.map((o) => (
              <TableRow key={o.id}>
                <TableCell className="whitespace-nowrap text-xs">{new Date(o.created_at).toLocaleString()}</TableCell>
                <TableCell className="text-xs">{o.email}</TableCell>
                <TableCell className="text-xs">{o.product_label}</TableCell>
                <TableCell className="max-w-48 text-xs">
                  <span className="font-medium">{o.shipping_name}</span>
                  <span className="block truncate text-muted-foreground">{o.shipping_address}</span>
                </TableCell>
                <TableCell className="font-mono text-xs">{o.pay_currency?.toUpperCase() ?? "—"}</TableCell>
                <TableCell className="text-right font-medium">{eur(o.amount_eur)}</TableCell>
                <TableCell>
                  <StatusBadge status={o.status} label={statusLabel[o.status] ?? o.status} />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </main>
  );
}
